mod input;
mod storage;

use input::{InputListener, InputStatus, RecordingState};
use std::sync::{Arc, Mutex};
use storage::{DashboardData, StatsStore};
use tauri::menu::{MenuBuilder, MenuItemBuilder, PredefinedMenuItem};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use tauri::{
    Emitter, Manager, PhysicalPosition, PhysicalSize, Position, Size, State, WebviewUrl,
    WebviewWindowBuilder,
};

#[tauri::command]
fn get_dashboard(
    range: Option<String>,
    store: State<'_, Arc<StatsStore>>,
) -> Result<DashboardData, String> {
    store.dashboard_range(range.as_deref().unwrap_or("today"))
}

#[tauri::command]
fn get_dashboard_custom(
    start: String,
    end: String,
    store: State<'_, Arc<StatsStore>>,
) -> Result<DashboardData, String> {
    store.dashboard_custom(&start, &end)
}

#[tauri::command]
fn set_recording(enabled: bool, recording: State<'_, RecordingState>) -> Result<(), String> {
    recording
        .enabled
        .store(enabled, std::sync::atomic::Ordering::Relaxed);
    Ok(())
}

#[tauri::command]
fn get_recording(recording: State<'_, RecordingState>) -> bool {
    recording.enabled.load(std::sync::atomic::Ordering::Relaxed)
}

#[tauri::command]
fn get_input_status(status: State<'_, InputStatus>) -> bool {
    status.available.load(std::sync::atomic::Ordering::Relaxed)
}

#[tauri::command]
fn clear_stats(store: State<'_, Arc<StatsStore>>) -> Result<(), String> {
    store.clear()
}

#[tauri::command]
fn toggle_keyshow(app: tauri::AppHandle) -> Result<bool, String> {
    toggle_keyshow_window(&app)
}

#[tauri::command]
fn set_keyshow_position(app: tauri::AppHandle, position: String) -> Result<(), String> {
    if app.try_state::<KeyshowPrefs>().is_none() { return Ok(()); }
    if !KEYSHOW_POSITIONS.contains(&position.as_str()) {
        return Err(format!("unsupported keyshow position: {position}"));
    }
    let prefs = app.state::<KeyshowPrefs>();
    *prefs
        .position
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())? = position;
    apply_keyshow_layout(&app)
}

#[tauri::command]
fn set_keyshow_size(app: tauri::AppHandle, size: String) -> Result<(), String> {
    if app.try_state::<KeyshowPrefs>().is_none() { return Ok(()); }
    if !KEYSHOW_SIZES.iter().any(|(id, _, _)| *id == size) {
        return Err(format!("unsupported keyshow size: {size}"));
    }
    let prefs = app.state::<KeyshowPrefs>();
    *prefs
        .size
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())? = size;
    apply_keyshow_layout(&app)
}

fn apply_window_opacity(window: &tauri::WebviewWindow, opacity: f64) -> Result<(), String> {
    #[cfg(windows)]
    {
        use windows::Win32::UI::WindowsAndMessaging::{
            SetLayeredWindowAttributes, LWA_ALPHA,
        };
        let hwnd = window.hwnd().map_err(|e| e.to_string())?;
        let alpha = (opacity.clamp(0.15, 1.0) * 255.0).round() as u8;
        unsafe {
            SetLayeredWindowAttributes(hwnd, windows::Win32::Foundation::COLORREF(0), alpha, LWA_ALPHA)
                .map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

#[tauri::command]
fn set_keyshow_opacity(app: tauri::AppHandle, opacity: f64) -> Result<(), String> {
    if app.try_state::<KeyshowPrefs>().is_none() { return Ok(()); }
    let window = app
        .get_webview_window("keys-overlay")
        .ok_or_else(|| "keyshow overlay window unavailable".to_string())?;
    let clamped = opacity.clamp(0.15, 1.0);
    *app.state::<KeyshowPrefs>()
        .opacity
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())? = clamped;
    apply_window_opacity(&window, clamped)
}

#[tauri::command]
fn set_keyshow_custom_position(app: tauri::AppHandle, x: i32, y: i32) -> Result<(), String> {
    if app.try_state::<KeyshowPrefs>().is_none() { return Ok(()); }
    let window = app
        .get_webview_window("keys-overlay")
        .ok_or_else(|| "keyshow overlay window unavailable".to_string())?;
    let prefs = app.state::<KeyshowPrefs>();
    let mut position = prefs
        .position
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())?;
    if *position != "custom" {
        *position = "custom".into();
    }
    *prefs
        .custom_position
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())? = Some((x, y));
    drop(position);
    window
        .set_position(Position::Physical(PhysicalPosition::new(x, y)))
        .map_err(|e| e.to_string())
}

/// Drag mode makes the overlay interactive (draggable by its handle) and turns
/// click-through off; locking it restores click-through.
#[tauri::command]
fn set_keyshow_drag_mode(app: tauri::AppHandle, enabled: bool) -> Result<(), String> {
    if app.try_state::<KeyshowPrefs>().is_none() { return Ok(()); }
    let window = app
        .get_webview_window("keys-overlay")
        .ok_or_else(|| "keyshow overlay window unavailable".to_string())?;
    *app.state::<KeyshowPrefs>()
        .drag_mode
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())? = enabled;
    window
        .set_ignore_cursor_events(!enabled)
        .map_err(|e| e.to_string())?;
    // Toggling click-through re-applies the window ex-style, which drops the
    // layered alpha set by SetLayeredWindowAttributes; replay the saved opacity.
    let opacity = *app
        .state::<KeyshowPrefs>()
        .opacity
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())?;
    apply_window_opacity(&window, opacity)?;
    let _ = app.emit("keyshow-dragmode", enabled);
    Ok(())
}

/// Built-in placements and sizes for the keyshow overlay window.
const KEYSHOW_POSITIONS: [&str; 6] = [
    "bottom-center",
    "bottom-left",
    "bottom-right",
    "top-center",
    "top-left",
    "top-right",
];
const KEYSHOW_SIZES: [(&str, f64, f64); 3] = [
    ("small", 860.0, 150.0),
    ("medium", 1080.0, 190.0),
    ("large", 1400.0, 250.0),
];

pub struct KeyshowPrefs {
    position: Mutex<String>,
    size: Mutex<String>,
    opacity: Mutex<f64>,
    drag_mode: Mutex<bool>,
    custom_position: Mutex<Option<(i32, i32)>>,
}

impl Default for KeyshowPrefs {
    fn default() -> Self {
        Self {
            position: Mutex::new("bottom-center".into()),
            size: Mutex::new("medium".into()),
            opacity: Mutex::new(1.0),
            drag_mode: Mutex::new(false),
            custom_position: Mutex::new(None),
        }
    }
}

fn keyshow_geometry(size: &str) -> (f64, f64) {
    KEYSHOW_SIZES
        .iter()
        .find(|(id, _, _)| *id == size)
        .map(|(_, w, h)| (*w, *h))
        .unwrap_or((1080.0, 190.0))
}

/// Compute the physical window bounds for the given placement inside the
/// monitor work area (the area excluding the taskbar).
fn keyshow_bounds(
    position: &str,
    area: &tauri::PhysicalRect<i32, u32>,
    scale: f64,
    width: f64,
    height: f64,
) -> (f64, f64) {
    let margin = 24.0 * scale;
    let left = area.position.x as f64 + margin;
    let right = area.position.x as f64 + area.size.width as f64 - width - margin;
    let top = area.position.y as f64 + margin;
    let bottom = area.position.y as f64 + area.size.height as f64 - height - margin;
    let center_x = area.position.x as f64 + (area.size.width as f64 - width) / 2.0;
    match position {
        "bottom-left" => (left, bottom),
        "bottom-right" => (right, bottom),
        "top-center" => (center_x, top),
        "top-left" => (left, top),
        "top-right" => (right, top),
        _ => (center_x, bottom),
    }
}

fn apply_keyshow_layout(app: &tauri::AppHandle) -> Result<(), String> {
    let window = app
        .get_webview_window("keys-overlay")
        .ok_or_else(|| "keyshow overlay window unavailable".to_string())?;
    let prefs = app.state::<KeyshowPrefs>();
    let position = prefs
        .position
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())?
        .clone();
    let size = prefs
        .size
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())?
        .clone();
    let (logical_w, logical_h) = keyshow_geometry(&size);
    let custom = prefs
        .custom_position
        .lock()
        .map_err(|_| "keyshow prefs poisoned".to_string())?
        .clone();
    if let Some(monitor) = window.primary_monitor().map_err(|e| e.to_string())? {
        let area = monitor.work_area();
        let scale = monitor.scale_factor();
        let width = logical_w * scale;
        let height = logical_h * scale;
        let (x, y) = if position == "custom" && custom.is_some() {
            let (cx, cy) = custom.unwrap();
            (cx as f64, cy as f64)
        } else {
            keyshow_bounds(&position, &area, scale, width, height)
        };
        window
            .set_size(Size::Physical(PhysicalSize::new(width as u32, height as u32)))
            .map_err(|e| e.to_string())?;
        window
            .set_position(Position::Physical(PhysicalPosition::new(x as i32, y as i32)))
            .map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn build_mini_overlay(app: &tauri::App) -> tauri::Result<()> {
    let mini = WebviewWindowBuilder::new(app, "keys-mini", WebviewUrl::App("index.html".into()))
        .title("KeyPulse Mini")
        .inner_size(230.0, 92.0)
        .decorations(false)
        .transparent(true)
        .always_on_top(true)
        .skip_taskbar(true)
        .resizable(false)
        .shadow(false)
        .focused(false)
        .visible(false)
        .build()?;
    mini.set_ignore_cursor_events(true)?;
    if let Some(monitor) = mini.primary_monitor()? {
        let area = monitor.work_area();
        let scale = monitor.scale_factor();
        let margin = 16.0 * scale;
        let width = 230.0 * scale;
        let height = 92.0 * scale;
        let x = area.position.x as f64 + area.size.width as f64 - width - margin;
        let y = area.position.y as f64 + margin;
        mini.set_size(Size::Physical(PhysicalSize::new(width as u32, height as u32)))?;
        mini.set_position(Position::Physical(PhysicalPosition::new(x as i32, y as i32)))?;
    }
    Ok(())
}

#[tauri::command]
fn toggle_mini(app: tauri::AppHandle) -> Result<bool, String> {
    let window = app
        .get_webview_window("keys-mini")
        .ok_or_else(|| "mini overlay window unavailable".to_string())?;
    let visible = window.is_visible().map_err(|error| error.to_string())?;
    if visible {
        window.hide().map_err(|error| error.to_string())?;
    } else {
        window.show().map_err(|error| error.to_string())?;
    }
    let _ = app.emit("mini-changed", !visible);
    Ok(!visible)
}

fn toggle_keyshow_window(app: &tauri::AppHandle) -> Result<bool, String> {
    let window = app
        .get_webview_window("keys-overlay")
        .ok_or_else(|| "keyshow overlay window unavailable".to_string())?;
    let visible = window.is_visible().map_err(|error| error.to_string())?;
    if visible {
        window.hide().map_err(|error| error.to_string())?;
    } else {
        window.show().map_err(|error| error.to_string())?;
    }
    let _ = app.emit("keyshow-changed", !visible);
    Ok(!visible)
}

fn build_keyshow_overlay(app: &tauri::App) -> tauri::Result<()> {
    let overlay =
        WebviewWindowBuilder::new(app, "keys-overlay", WebviewUrl::App("index.html".into()))
            .title("KeyPulse Keyshow")
            .inner_size(1080.0, 190.0)
            .decorations(false)
            .transparent(true)
            .always_on_top(true)
            .skip_taskbar(true)
            .resizable(false)
            .shadow(false)
            .focused(false)
            .visible(false)
            .build()?;
    overlay.set_ignore_cursor_events(true)?;
    Ok(())
}

/// Where the SQLite database lives. `appdata` = %APPDATA% (default, works for
/// installed builds); `appdir` = a writable folder next to the executable
/// (portable setups that do not want to grow the system drive).
fn preferences_path(app: &impl tauri::Manager<tauri::Wry>) -> std::path::PathBuf {
    app.path()
        .app_config_dir()
        .map(|dir| dir.join("preferences.json"))
        .unwrap_or_else(|_| std::env::temp_dir().join("keypulse-preferences.json"))
}

fn read_data_location(app: &impl tauri::Manager<tauri::Wry>) -> String {
    let file = preferences_path(app);
    if let Ok(raw) = std::fs::read_to_string(&file) {
        if let Ok(value) = serde_json::from_str::<serde_json::Value>(&raw) {
            if let Some(kind) = value.get("dataLocation").and_then(|v| v.as_str()) {
                return kind.to_string();
            }
        }
    }
    "appdata".into()
}

fn write_data_location(app: &impl tauri::Manager<tauri::Wry>, kind: &str) -> Result<(), String> {
    let file = preferences_path(app);
    if let Some(parent) = file.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let value = serde_json::json!({ "dataLocation": kind });
    std::fs::write(&file, serde_json::to_string_pretty(&value).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())
}

fn resolve_db_path(app: &impl tauri::Manager<tauri::Wry>) -> Result<std::path::PathBuf, String> {
    let location = read_data_location(app);
    if location == "appdir" {
        let exe_dir = std::env::current_exe()
            .map_err(|e| e.to_string())?
            .parent()
            .map(|p| p.to_path_buf())
            .ok_or_else(|| "cannot resolve executable directory".to_string())?;
        let candidate = exe_dir.join("keypulse-data");
        // Installed builds live under Program Files which is read-only for
        // normal users; fall back to AppData when the portable folder is not
        // writable.
        if std::fs::create_dir_all(&candidate).is_ok() {
            let probe = candidate.join(".write-test");
            if std::fs::write(&probe, b"1").is_ok() {
                let _ = std::fs::remove_file(&probe);
                return Ok(candidate.join("keypulse.sqlite"));
            }
        }
    }
    let appdata = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?;
    std::fs::create_dir_all(&appdata).map_err(|e| e.to_string())?;
    Ok(appdata.join("keypulse.sqlite"))
}

/// Move the SQLite file (plus WAL/SHM sidecars) to the requested location and
/// record the preference. Takes effect on the next launch.
#[tauri::command]
fn set_data_location(app: tauri::AppHandle, kind: String) -> Result<String, String> {
    if kind != "appdata" && kind != "appdir" {
        return Err(format!("unsupported data location: {kind}"));
    }
    let current = resolve_db_path(&app)?;
    let target_dir = if kind == "appdir" {
        let exe_dir = std::env::current_exe()
            .map_err(|e| e.to_string())?
            .parent()
            .map(|p| p.to_path_buf())
            .ok_or_else(|| "cannot resolve executable directory".to_string())?;
        exe_dir.join("keypulse-data")
    } else {
        app.path()
            .app_data_dir()
            .map_err(|e| e.to_string())?
    };
    std::fs::create_dir_all(&target_dir).map_err(|e| e.to_string())?;
    let target = target_dir.join("keypulse.sqlite");
    if current != target {
        if !target.exists() && current.exists() {
            for suffix in ["", "-wal", "-shm"] {
                let src = std::path::PathBuf::from(format!("{}{}", current.display(), suffix));
                if src.exists() {
                    std::fs::copy(&src, format!("{}{}", target.display(), suffix))
                        .map_err(|e| format!("copy failed: {e}"))?;
                }
            }
        }
        write_data_location(&app, &kind)?;
    }
    let dir = target.parent().map(|p| p.display().to_string()).unwrap_or_default();
    Ok(format!("数据位置已切换为：{dir}\\keypulse.sqlite（重启后生效）"))
}

#[tauri::command]
fn get_data_location(app: tauri::AppHandle) -> Result<String, String> {
    let path = resolve_db_path(&app)?;
    Ok(format!(
        "{}|{}",
        read_data_location(&app),
        path.display().to_string()
    ))
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let db_path = resolve_db_path(app).map_err(std::io::Error::other)?;
            if let Some(parent) = db_path.parent() {
                std::fs::create_dir_all(parent)?;
            }

            let store = StatsStore::open(&db_path).map_err(std::io::Error::other)?;
            let recording = RecordingState::default();
            let input_status = InputStatus::default();
            let listener_store = Arc::clone(&store);
            let listener_recording = recording.clone();
            let listener_status = input_status.clone();
            app.manage(store);
            app.manage(recording);
            app.manage(input_status);
            match InputListener::start(app.handle().clone(), listener_store, listener_recording) {
                Ok(listener) => {
                    listener_status
                        .available
                        .store(true, std::sync::atomic::Ordering::Relaxed);
                    app.manage(listener);
                }
                Err(error) => {
                    eprintln!("KeyPulse input listener unavailable: {error}");
                }
            }

            app.manage(KeyshowPrefs::default());
            build_keyshow_overlay(app)?;
            build_mini_overlay(app)?;
            apply_keyshow_layout(app.handle()).map_err(std::io::Error::other)?;
            setup_tray(app)?;
            Ok(())
        })
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![
            get_dashboard,
            get_dashboard_custom,
            set_recording,
            get_recording,
            get_input_status,
            clear_stats,
            toggle_keyshow,
            set_keyshow_position,
            set_keyshow_size,
            set_keyshow_opacity,
            set_keyshow_custom_position,
            set_keyshow_drag_mode,
            toggle_mini,
            set_data_location,
            get_data_location
        ])
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                api.prevent_close();
                let _ = window.hide();
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

fn setup_tray(app: &mut tauri::App) -> Result<(), Box<dyn std::error::Error>> {
    let show = MenuItemBuilder::with_id("show", "打开 KeyPulse").build(app)?;
    let toggle = MenuItemBuilder::with_id("toggle-recording", "暂停/继续记录").build(app)?;
    let keyshow = MenuItemBuilder::with_id("toggle-keyshow", "按键可视化：关").build(app)?;
    let clear = MenuItemBuilder::with_id("clear-stats", "清空本地统计").build(app)?;
    let separator = PredefinedMenuItem::separator(app)?;
    let quit = PredefinedMenuItem::quit(app, Some("退出 KeyPulse"))?;
    let menu = MenuBuilder::new(app)
        .items(&[&show, &toggle, &keyshow, &clear, &separator, &quit])
        .build()?;

    let mut tray = TrayIconBuilder::with_id("keypulse-tray")
        .menu(&menu)
        .tooltip("KeyPulse 键鼠热力图")
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                if let Some(window) = tray.app_handle().get_webview_window("main") {
                    let _ = window.show();
                    let _ = window.set_focus();
                }
            }
        })
        .on_menu_event({
            let keyshow_menu_item = keyshow.clone();
            move |app, event| match event.id.as_ref() {
                "show" => {
                    if let Some(window) = app.get_webview_window("main") {
                        let _ = window.show();
                        let _ = window.set_focus();
                    }
                }
                "toggle-recording" => {
                    if let Some(recording) = app.try_state::<RecordingState>() {
                        let enabled = !recording.enabled.load(std::sync::atomic::Ordering::Relaxed);
                        recording
                            .enabled
                            .store(enabled, std::sync::atomic::Ordering::Relaxed);
                        let _ = app.emit("recording-changed", enabled);
                    }
                }
                "toggle-keyshow" => {
                    if let Ok(visible) = toggle_keyshow_window(app) {
                        let label = if visible {
                            "按键可视化：开"
                        } else {
                            "按键可视化：关"
                        };
                        let _ = keyshow_menu_item.set_text(label);
                    }
                }
                "clear-stats" => {
                    if let Some(store) = app.try_state::<Arc<StatsStore>>() {
                        if store.clear().is_ok() {
                            if let Ok(snapshot) = store.dashboard_today() {
                                let _ = app.emit("stats-updated", snapshot);
                            }
                        }
                    }
                }
                _ => {}
            }
        });

    if let Some(icon) = app.default_window_icon().cloned() {
        tray = tray.icon(icon);
    }
    app.manage(tray.build(app)?);
    Ok(())
}
